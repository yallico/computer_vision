20-11-2024

This is a copy of the best implementation I have so far. It has changes to the functions and data processing from the original, something I need to discuss with you all. For now, please follow these instructions:

1. Make a Conda Environment for CSRNet and install requirements.txt
2. Load in our data into 'dataset', link provided on the Git

Then follow the notebooks in this order:

1. dataset_preparation.ipynb
2. CSV_to_H5.ipynb
3. make_dataset.ipynb
4. make_json.ipynb

Once the model is trained and you have checkpoints:

5. CSRNET_apple.ipynb

CW