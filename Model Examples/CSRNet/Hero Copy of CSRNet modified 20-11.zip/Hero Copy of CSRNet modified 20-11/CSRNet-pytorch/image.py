import random
import os
from PIL import Image
import numpy as np
import h5py
import cv2

def load_data(data_record, train=True):
    img_path = data_record["image"]
    gt_path = data_record["ground_truth"]

    # Load the image file
    img = Image.open(img_path).convert('RGB')

    # Load the ground truth density map with error handling
    with h5py.File(gt_path, 'r') as gt_file:
        if 'density' in gt_file:
            target = np.asarray(gt_file['density'])
        else:
            img_shape = img.size[::-1]
            target = np.zeros((img_shape[0], img_shape[1]), dtype=np.float32)

    # Resize target to be 1/8th the size of the image, rounding to avoid mismatch
    target_h = round(img.size[1] / 8)
    target_w = round(img.size[0] / 8)
    target = cv2.resize(target, (target_w, target_h), interpolation=cv2.INTER_CUBIC) * 64

    # Apply data augmentation if train is set to True
    if train:
        crop_size = (img.size[0] // 2, img.size[1] // 2)
        dx = dy = 0
        if random.random() > 0.8:
            dx = int(random.random() * img.size[0] // 2)
            dy = int(random.random() * img.size[1] // 2)

        # Crop image and target
        img = img.crop((dx, dy, crop_size[0] + dx, crop_size[1] + dy))
        target = target[dy // 8: (crop_size[1] + dy) // 8, dx // 8: (crop_size[0] + dx) // 8]

        # Random horizontal flip
        if random.random() > 0.8:
            target = np.fliplr(target)
            img = img.transpose(Image.FLIP_LEFT_RIGHT)

    # Ensure positive strides
    target = target.copy()

    return img, target
